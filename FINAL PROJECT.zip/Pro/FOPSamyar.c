#include <stdio.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include<time.h>
#include<ctype.h>
#include<math.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
//For songs
#define NUM_SONGS 3
//For ScoreTable
#define MAX_LINE_LENGTH 100
#define MAX_USERS 1000

typedef struct 
{
    char username[MAX_LINE_LENGTH];
    int score;
    int golds;
    int gameplayed;
} User;
User users[MAX_USERS];

typedef struct
 {
    char username[50];
    int score;
    int gold;
    int gameplayed;
}Carbar;
Carbar nowuser;

typedef struct {
    char username[50];
    int scores;
    int goldsss;
    int gameplayedsss;
}SavePlayer;


char Playercolor[10];
int Personnumber;
char Name_of_User[50];
char Name_of_login_user[50];

struct Person
{
    char Username[70];
    char Password[70];
    char email[70];
};
////////////////////
//For File
FILE *fptr;
FILE* Mapptr;
//For Generate password or Random password
char GenerateRandom;
////////////////////////////////////////////////
//Room items////////////////////////////////////
////////////////////////////////////////////////
struct room
{
   int start_x;
   int start_y;
   int height;
   int width;
   int show;
};
 struct otaagh
{
   struct room current_floor[4];
}Rooms[6];


 
//map of Game
char map[56][205];


int log_or_regi=0;
//
int Gold=0;
int Score=0;
int Gameplayed=0;



int PlayerHealth=100;
int hungry=100;

int foods=0;

int foodhealth=0;


int stephealth=0;



int baars=0;
/***************************************Start LOGIN REGISTERATION PROCCESS*******************************************?
 */
/////////////////////////////////////
//////////Play--Music////////////////
/////////////////////////////////////

const char* songs[NUM_SONGS] = {
    "Music1.mp3",
    "Music2.mp3",
    "Music3.mp3"
};

int currentSong = 0;
int volume = MIX_MAX_VOLUME / 2; 
int isPlaying = 1; 

void playMusic(const char* filePath) {
    if (SDL_Init(SDL_INIT_AUDIO) < 0) {
        printw("SDL could not initialize! SDL Error: %s\n", SDL_GetError());
        refresh();
        getch();
        return;
    }

    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        printw("SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
        refresh();
        getch();
        return;
    }

    Mix_Music *music = Mix_LoadMUS(filePath);
    if (music == NULL) {
        printw("Failed to load music file! SDL_mixer Error: %s\n", Mix_GetError());
        refresh();
        getch();
        return;
    }

    Mix_VolumeMusic(volume); 
    Mix_PlayMusic(music, -1);
}
/////////////////////////////////////
////////////DarHashie////////////////
/////////////////////////////////////
void DarHashie()
{
   init_pair(5,COLOR_WHITE,COLOR_BLACK);
         attron(COLOR_PAIR(5));
         mvprintw(5,20,"##############################################################################################################################################################\n");
         for (int i = 6 ;i < 51; i++)
         {
           mvprintw(i,20,"#");
         }
         for (int j = 6; j <51 ; j++)
         {
            mvprintw(j,177,"#");
         }
         
         mvprintw(51,20,"##############################################################################################################################################################\n");
         mvprintw(6,81,"(((((((((((((:Rogue:))))))))))))))");
}
/////////////////////////////////////
/////////////RandomMaker/////////////
/////////////////////////////////////
char RandomMaker()
{
    char Posibilities[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    int a= rand() % (sizeof(Posibilities)-1);
    return Posibilities[a];
}
/////////////////////////////////////
///////generate_password/////////////
/////////////////////////////////////
void generate_password(char* Password,int length)
{
   //color
   DarHashie();
   int upper=0; int lower=0; int digit=0;
   for (int i = 0; i < length; i++)
   {
    Password[i]=RandomMaker();
    if(Password[i]>=65 && Password[i]<= 90)
    {
        upper=1;
    }
    else if(Password[i]>= 97 && Password[i]<=122)
    {
        lower=1;
    }
    else if(Password[i]>=48 && Password[i]<=57)
    {
        digit=1;
    }
   }
   if(upper==0)
   {
    Password[rand()% length]='A'+(rand()% 20);
   }
   if( lower==0)
   {
     Password[rand()% length]='a'+(rand()% 20);
   }
   if(digit==0)
   {
     Password[rand()% length]='0'+(rand()% 9);
   }
   Password[length]='\0';
}
/////////////////////////////////////
///////Forgot my password////////////
/////////////////////////////////////
void Forgot_my_Password()
{
   //color
   DarHashie();
   char username[200];
   char Pass[200];
   mvprintw(25,65,"Please enter your Username:\n");
   DarHashie();
   refresh();
    move(26,65);
    scanw("%s",username);
    char line[1000];
    int targetPerson;
    fptr=fopen("Project.txt","r");
    while(fgets(line,sizeof(line),fptr))
    {
      if(strncmp(line,"Username :",10)==0)
      {
         char Username[70];
         sscanf(line,"Username : %s", Username);
         if(strcmp(username,Username)==0)
         {
            DarHashie();
            fgets(line,sizeof(line),fptr);
            sscanf(line,"Password : %s",Pass);
            mvprintw(27,65,"Your Password is: %s\n",Pass);
            mvprintw(28,65,"If you want to login,Press 'l'\n");
            mvprintw(29,65,"If you want to exit press 'e'\n");
            DarHashie();
            refresh();
            move(30,65);
            char g=getch();
            if(g=='l' || g=='l')
            {
               clear();
              Login();
              break;
            }
            else if(g=='e' || g=='E')
            {
               clear();
               refresh();
               endwin();
               exit(0);
            }
         }
      }
    }
}
/////////////////////////////////////
////////////Kapcha///////////////////
/////////////////////////////////////
int MonsterChecker()
{
   //color
   DarHashie();
  while(1)
  {
   int num_1,num_2,correct_sum,inputnumber;
   srand(time(NULL));
   num_1=rand()%70;
   num_2=rand()%70;
   correct_sum=num_1+num_2;
   mvprintw(17,65,"Enter the correct answer of %d + %d\n",num_1,num_2);
   //Shape of Monster
    init_pair(25,COLOR_CYAN,COLOR_BLACK);
    attron(COLOR_PAIR(25));
    mvprintw(19, 60, "                         |\\   \\        /        /|");
    mvprintw(20, 60, "                        /  \\  |\\__  __/|       /  \\");
    mvprintw(21, 60, "                       / /\\ \\ \\ _ \\/ _ /      /    \\");
    mvprintw(22, 60, "                      / / /\\ \\ {*}\\/{*}      /  / \\ \\");
    mvprintw(23, 60, "                      | | | \\ \\( (00) )     /  // |\\ \\");
    mvprintw(24, 60, "                      | | | |\\ \\(V\"\"V)\\    /  / | || \\|");
    mvprintw(25, 60, "                      | | | | \\ |^--^| \\  /  / || || ||");
    mvprintw(26, 60, "                     / / /  | |( WWWW__ \\/  /| || || ||");
    mvprintw(27, 60, "                     | | | | | |  \\______\\  / / || || ||");
    mvprintw(28, 60, "                     | | | / | | )|______\\ ) | / | || ||");
    mvprintw(29, 60, "                    / / /  / /  /______/   /| \\ \\ || ||");
    mvprintw(30, 60, "                   / / /  / /  /\\_____/  |/ /__\\ \\ \\ \\ \\");
    mvprintw(31, 60, "                   | | | / /  /\\______/    \\   \\__| \\ \\ \\");
    mvprintw(32, 60, "                   | | | | | |\\______ __    \\_    \\__|_| \\");
    mvprintw(33, 60, "                   | | ,___ /\\______ _  _     \\_       \\  |");
    mvprintw(34, 60, "                   | |/    /\\_____  /    \\      \\__     \\ |    /\\");
    mvprintw(35, 60, "                   |/ |   |\\______ |      |        \\___  \\ |__/  \\");
    mvprintw(36, 60, "                   v  |   |\\______ |      |            \\___/     |");
    mvprintw(37, 60, "                      |   |\\______ |      |                    __/");
    mvprintw(38, 60, "                       \\   \\________\\_    _\\               ____/");
    mvprintw(39, 60, "                     __/   /\\_____ __/   /   )\\_,      _____/");
    mvprintw(40, 60, "                    /  ___/  \\uuuu/  ___/___)    \\______/");
    mvprintw(41, 60, "                    VVV  V        VVV  V");
    attroff(COLOR_PAIR(25));
     DarHashie();
   move(18,65);
   scanw("%d",&inputnumber);
   
      if(inputnumber==correct_sum)
      {
         clear();
         mvprintw(19,65,"WOW,you are not a Monster!\n");
         //Hashie
         DarHashie();
         return 1;
      }
      else
      {
         clear();
         mvprintw(20,65,"Maybe you are a Monster!!!!!. No? Try again:)\n");
         //color
         DarHashie();
         continue;
    
      }
   }
}
/////////////////////////////////////
///////Login_Register////////////////
/////////////////////////////////////
char Login_Register()
{
   mvprintw(30,70,"Do you want to login or register?\n");
   mvprintw(32,70,"If you want to play as a GUEST press G!\n");
   mvprintw(34,70,"Or if you don't want,press L for Login or R for Register\n");
   noecho();
   char input;
   //Hashie
   DarHashie();
   move(35,70);
   scanw("%c", &input);
   if (input == 'L' || input == 'l')
   {
      clear();
      return 'L';
   }
   else
   {
      if (input == 'R' || input == 'r')
      {
         clear();
         return 'R';
      }
      else if(input=='G' || input=='g')
      {
         return 'G';
      }
      else
      {
         clear();
         printf("You entered wrong input!\n");
         return 'E';
      }
   }
}
/////////////////////////////////////
////////////////Register/////////////
/////////////////////////////////////
int PersonValue=1;                                                   
void Register()
{
   //color
   DarHashie();
   char Password[70];
   char again_Password[70];
   char email[70];
   struct Person *ptr;
   ptr= (struct Person*)malloc(100000*sizeof(struct Person));
   fptr=fopen("Project.txt","r");
   char lines[1000];
   while(fgets(lines,sizeof(lines),fptr))
   {
      int a;
     if(strncmp(lines,"Person",6)==0)
     {
      sscanf(lines,"Person %d",&a);
     }
   PersonValue=a+1;
   }
   fclose(fptr);
   mvprintw(30,80,"Please enter your username:\n");
   DarHashie();
   move(31,80);
   while (1)
   {
      
      echo();
      move(32,80);
      scanw("%s",&(ptr+PersonValue)->Username);
      strcpy(Name_of_User,(ptr+PersonValue)->Username);
      log_or_regi=1;
      if (strlen((ptr+PersonValue)->Username) == 0)
      {
         DarHashie();
         refresh();
         mvprintw(31,80,"You didn't enter any USERNAMES! Please enter that:\n");
         DarHashie();
         refresh();
         continue;
      }
         int a=0;
         char line[1000];
         fptr = fopen("Project.txt", "r");
         while(fgets(line,sizeof(line),fptr))
         {
            if(strncmp(line,"Username",8)==0)
            {
               char Saved_Usernames[70];
               
               sscanf(line,"Username : %s",Saved_Usernames);
               if(strcmp(Saved_Usernames,(ptr+PersonValue)->Username)==0)
               {
                  a++;
                  clear();
                  mvprintw(30,80,"Your entered username has already used!\n");
                  mvprintw(31,80,"Please enter another username!:\n");
                  //Hashie
                  DarHashie();
                  move(32,80);
                  break;
               }
            }
         }
         fclose(fptr);
         if(a==0)
         {   
         fptr=fopen("Project.txt","a");
         fprintf(fptr,"__________\n");
         fprintf(fptr,"Person %d informations:\n",PersonValue);
         fclose(fptr);
         fptr=fopen("Project.txt","a");
         fprintf(fptr,"Username : %s\n",(ptr+PersonValue)->Username);
         fclose(fptr);
         break;
         }
      
   }
   while (1)
   {
      clear();
      mvprintw(30,80,"If you want to make a password press '1'\n");
      mvprintw(31,80,"If you want to have a random password press '2'\n");
       //Hashie
      DarHashie();
      move(32,80);
      GenerateRandom=getch();
      if(GenerateRandom=='1')
      {       
     clear();
     //color
     DarHashie();
     // Password
     int incorrect_keys = 0;
    while (1)
    {
      if (incorrect_keys >= 3)
      {
         clear();
         mvprintw(25,65,"You entered more than 3 incorrect passwords! \n");
         mvprintw(26,65,"Because of that you waited for 30 seconds!\n");
         if (incorrect_keys >= 3)
         {
            sleep(30);
            incorrect_keys = 0;
         }
      }

     //make password       
      mvprintw(25,65,"Please enter correct password!\n");
      mvprintw(26,65,"It should has an Uppercase(ore more), a lowercase(or more),a number(or more) and minimum length 7\n");
      //Hashie
      DarHashie();
      move(27,65);
      scanw("%s", &(ptr+PersonValue)->Password);
      strcpy(Password,(ptr+PersonValue)->Password);
      int big = 0;
      int small = 0;
      int ragham = 0;
      for (int i = 0; i < strlen(Password); i++)
      {
         if (Password[i] >= 65 && Password[i] <= 90)
         {
            big++;
         }
         else if (Password[i] >= 97 && Password[i] <= 122)
         {
            small++;
         }
         else if (Password[i] >= 48 && Password[i] <= 57)
         {
            ragham++;
         }
      }
      if (big == 0 || small == 0 || ragham == 0 || strlen(Password) < 7)
      {
         clear();
         mvprintw(25,65,"You entered wrong Password!\n");
         incorrect_keys++;
         if (incorrect_keys >= 3)
            clear();
      }
      else
      {
         fptr = fopen("Project.txt", "a");
         fprintf(fptr,"Password : %s\n",(ptr+PersonValue)->Password);
         fclose(fptr);
         clear();
         break;
      }
   }

   // Password_again
       while (1)
      {
         mvprintw(25,65,"Please enter your Password again:\n");
         //Hashie
         DarHashie();
         move(26,65);
         scanw("%s", again_Password);
         if (strcmp(Password, again_Password) == 0)
         {
            clear();
            break;
         }
          else
         {
          clear();
         mvprintw(24,65,"It is not the same as previous Password. Please enter it again!\n");
         //Hashie
         DarHashie();
         }
      }
      break; 
   }
   if(GenerateRandom=='2')
    {
       clear();
       char Passsword[70];
       srand(time(NULL));
       int length=7;
       generate_password(Passsword,length);
       mvprintw(15,65,"To make sure you are not a !!!!MONSTER!!!\n");
       mvprintw(16,65,"tell me what is the result of the following equatuion:??\n");
       int a=MonsterChecker();
       if(a==1)
       {

       mvprintw(20, 110, "  (O_/ __ \\_O) ");
       mvprintw(22, 110, " (__.--\\/--.__) ");
       mvprintw(23, 110, " ====(__/\\__)==== ");
       mvprintw(24, 110, "      `--' ");
       mvprintw(26, 110, "    /'....'\\ ");
       mvprintw(27, 110, "   | :    : | ");
       mvprintw(28, 110, "   ||:    :|| ");
       mvprintw(29, 110, "   ||:    :|| ");
       mvprintw(30, 110, "   ||:    :|| ");
       mvprintw(31, 110, "   ||:    :|| ");
       mvprintw(32, 110, "   ||:    :|| ");
       mvprintw(33, 110, "   ||:    :|| ");
       mvprintw(34, 110, "   ||:    :|| ");
       mvprintw(35, 110, "   || `..' || ");
       mvprintw(36, 110, "   ( | || | ) ");
       mvprintw(37, 110, "    \\| || |/ ");
       mvprintw(38, 110, "     | || | ");
       mvprintw(39, 110, "     | || | ");
       mvprintw(40, 110, "     | || | ");
       mvprintw(41, 110, "     | || | ");
       mvprintw(42, 110, "     | || | ");
       mvprintw(43, 110, "     | || | ");
       mvprintw(44, 110, " __,-' || '-,__ ");
       mvprintw(45, 110, " (___,--'`--,___) ");
       mvprintw(21,65,"Your created password(By us) is: %s\n",Passsword);
       mvprintw(21, 110, "  / (o)__(o) \\ ");
       fptr=fopen("Project.txt","a");
       fprintf(fptr,"Password : %s\n",Passsword);
       fclose(fptr);
       break;
       }
       else
       {
         continue;
       }
    }
   else
   {
      clear();
      printw("You should enter one of these keys! Please try again!!!!\n");
      continue;
   }

   }

   // Email
   while (1)
   {
      
      mvprintw(25,65,"Please enter your E_mail:\n");
      //Hashie
      DarHashie();
      move(26,65);
      scanw("%s",&(ptr+PersonValue)->email);
      strcpy(email,(ptr+PersonValue)->email);
      // first Bug
      char *atsign = strrchr(email, '@');
      if (atsign == NULL)
      {
         clear();
         mvprintw(24,65,"invalid email!\n");
         continue;
      }
      // Second Bug
      int dot = 0;
      for (int i = 0; i < strlen(email); i++)
      {
         if (email[i] == '.')
         {
            dot++;
         }
      }
      if (dot == 0)
      {
         mvprintw(24,65,"invalid email!\n");
         continue;
      }
      // Third Bug
      char *Noghteh = strrchr(email, '@');
      int NumberOfDot = 0;
      for (int i = 0; i < strlen(Noghteh); i++)
      {
         if (Noghteh[i] == '.')
         {
            NumberOfDot++;
         }
      }
      if (NumberOfDot == 0)
      {
         mvprintw(24,65,"invalid email!\n");
         continue;
      }
      //Fourth Bug
      char* Atsign_dot=strrchr(email,'@');
      if(Atsign_dot!=NULL && *(Atsign_dot+1)=='.' )
      {
         clear();
         mvprintw(24,65,"invalid email!\n");
         continue;
      }
      //Fifth Bug
      char* AfterDot= strrchr(email,'.');
      if(AfterDot!=NULL && strlen(AfterDot)==1)
      {
         clear();
         mvprintw(24,65,"invalid email!\n");
         continue;
      }
      // Accept
      else
      {
         clear();
         DarHashie();
         refresh();
         mvprintw(27,86,"Registeration Completed!\n");
         attron(COLOR_PAIR(25));
         mvprintw(28,86,"Welcome! %s\n",(ptr+PersonValue)->Username);
         attroff(COLOR_PAIR(25));
         mvprintw(29,86,"Press 'Enter' to continue!\n");
         move(30,86);
         DarHashie();
         attron(COLOR_PAIR(25));
         //SUT 2025
         refresh();
         mvprintw(32, 70, "  ____  ");
         mvprintw(33, 70, "/ ___| ");
         mvprintw(34, 70, "| \\__");
         mvprintw(35, 70, "\\___ \\ ");
         mvprintw(36, 70, " ___) |");
         mvprintw(37, 70, "|____/ ");

         // حرف U
         mvprintw(32, 79, " _    _ ");
         mvprintw(33, 79, "| |  | |");
         mvprintw(34, 79, "| |  | |");
         mvprintw(35, 79, "| |  | |");
         mvprintw(36, 79, "| |__| |");
         mvprintw(37, 79, " \\____/ ");

         // حرف T
         mvprintw(32, 88, " _____");
         mvprintw(33, 88, "|_   _|");
         mvprintw(34, 88, "  | | ");
         mvprintw(35, 88, "  | |  ");
         mvprintw(36, 88, "  | |  ");
         mvprintw(37, 88, "  |_|  ");

         // عدد 2
         mvprintw(32, 97, " ___  ");
         mvprintw(33, 97, "|__ \\ ");
         mvprintw(34, 97, "   ) |");
         mvprintw(35, 97, "  / / ");
         mvprintw(36, 97, " / /_ ");
         mvprintw(37, 97, "|____|");

         // عدد 0
         mvprintw(32, 106, "  ___  ");
         mvprintw(33, 106, " / _ \\ ");
         mvprintw(34, 106, "| | | |");
         mvprintw(35, 106, "| | | |");
         mvprintw(36, 106, "| |_| |");
         mvprintw(37, 106, " \\___/ ");

         // عدد 2
         mvprintw(32, 115, " ___  ");
         mvprintw(33, 115, "|__ \\ ");
         mvprintw(34, 115, "   ) |");
         mvprintw(35, 115, "  / / ");
         mvprintw(36, 115, " / /_ ");
         mvprintw(37, 115, "|____|");

         // عدد 5
         mvprintw(32, 124, " _____ ");
         mvprintw(33, 124, "| ____|");
         mvprintw(34, 124, "| |__  ");
         mvprintw(35, 124, "|___ \\ ");
         mvprintw(36, 124, " ___) |");
         mvprintw(37, 124, "|____/ ");


         attroff(COLOR_PAIR(25));
          move(30,86);
          char m=getch();
          
         /////
         //Hashie
         DarHashie();
         refresh();
         fptr = fopen("Project.txt", "a");
         fprintf(fptr, "email = %s\n",(ptr+PersonValue)->email);
         fprintf(fptr,"Score=3\n");
         fprintf(fptr,"Golds=3\n");
         fprintf(fptr,"Gameplayed=0\n");
         fclose(fptr);
         PersonValue++;
         //Calling MenuGame
         clear();
         Login(PersonValue);
         break;
      }
   }
}
//////////////////////////////
//////////Login///////////////
//////////////////////////////
int Login()
{
   echo();
   char username[50];
   char password[60];
   char passwordvoroodi[60];
   int found=0;
   while(1)
   {

    mvprintw(25,65,"Please enter your Username:\n");
    //Hashie
    DarHashie();
    move(26,65);
    scanw("%s",username);
    char line[1000];
    int targetPerson;
    fptr=fopen("Project.txt","r");
    while(fgets(line,sizeof(line),fptr))
    {
      if(strncmp(line,"Username :",10)==0)
      {
         char Username[70];
         sscanf(line,"Username : %s", Username);
         if(strcmp(username,Username)==0)
         {
            found=1;
            break;
         }
      }
    }
    if(found==1)
    {

      mvprintw(27,65,"Please enter your password:\n");
      //Hashie
      DarHashie();
      move(28,65);
      scanw("%s",passwordvoroodi);
      if(fgets(line,sizeof(line),fptr))
      {
         sscanf(line,"Password : %s",password);
         if(strcmp(password,passwordvoroodi)==0)
         {
            strcpy(Name_of_login_user,username);
            clear();
            DarHashie();
            refresh();
            log_or_regi=2;
            mvprintw(27,85,"!!!!!WELCOME %s!!!!!",Name_of_login_user);
            mvprintw(28,85,"Press 'ENTER' to Continue");
            DarHashie();
            move(29,85);
            char c=getch();
            GameMenu(PersonValue);
         }
         else
         {
            clear();
            mvprintw(15,65,"Your entered password is incorrect!\n");
            mvprintw(16,65,"Press 't' to try again!\n");
            mvprintw(17,65,"\n\n\n\n\n");
            mvprintw(23,65,"Forgot your password??????? press 'f'\n");
            //Hashie
            DarHashie();
            move(24,65);
            char forgot_or_try=getch();
            if(forgot_or_try=='t' || forgot_or_try=='T')
            {
               continue;
            }
            else if(forgot_or_try=='f' || forgot_or_try=='F')
            {
            clear();
              Forgot_my_Password();
              break;
            }
         }
      }
    }
    
    fclose(fptr);
    while(1)
    {
    clear();
    mvprintw(25,65,"Your entered Username was not found!\n");
    mvprintw(26,65,"If you want to try again, press 't'\n");
    mvprintw(27,65,"\n\n");
    attron(A_UNDERLINE);
    mvprintw(29,65,"Want to Register??? press 'r'\n");
    attroff(A_UNDERLINE);
    //Hashie
    DarHashie();
    move(30,65);
    char s=getch();
    if(s=='t')
    {
      clear();
      break;
    }
    else if(s=='r')
    {
      Register();
      break;
    }
    }
   }


}
/////////////////////////////////////////////////////////////
//////////////Finding the Name of entered Member/////////////
/*void findUsernameByNumber(int personNumber) {
    fptr = fopen("Project.txt", "r");
    if (fptr == NULL) {
        printf("Failed to open file\n");
        return;
    }

    char buffer[256];
    char targetLabel[40];
    snprintf(targetLabel, sizeof(targetLabel), "Person %d informations:", personNumber);

    while (fgets(buffer, 256, fptr) != NULL)
     {
        if (strstr(buffer, targetLabel) != NULL)
         {
            // Read until we find "Username"
            while (fgets(buffer, 256, fptr) != NULL)
             {
                if (strstr(buffer, "Username :") != NULL)
                 {
                    char *username = strchr(buffer, ':') + 2;
                    strcpy(Name_of_User,username);
                    fclose(fptr);
                    return;
                }
            }
        }
    }

    printf("Person %d not found\n", personNumber);
    fclose(fptr);
}*/
////////////////End of Login/Registration Proccess///////////
//************************************************************************************************************************ */
///////////////////////////Functions of Game Menu//////////////////////
//////FirstFunction:NewGame and functions//////////////////
//Gameover
void Gameover()
{
       initscr();
       clear();
       refresh();
       DarHashie();
       clear();
       keypad(stdscr,TRUE);
       Gameplayed=Gameplayed+1;
       int Bazianjamshodeh;
        mvprintw(20,96, "!GAME OVER!");
           
        mvprintw(47,88,"Press 'r' to back to main menu") ;  
        
          int num;
        for (int i = 0; i < 1000; i++)
        {
         if(strcmp(users[i].username,Name_of_login_user)==0)
         {
           num=i;
         }
        }
        mvprintw(37,90,"%s   You lost!",users[num].username);
        //golds
        int nowgolds=users[num].golds+Gold;
        mvprintw(40,93,"Gols: %d",nowgolds);
        //scores
        int nowscores=users[num].score+Score;
        mvprintw(42,93,"Scores: %d",nowscores);
        //gameplayed
        int nowgameplayed=users[num].gameplayed+Gameplayed;
        mvprintw(44,93,"GamePlayed: %d",nowgameplayed);
        
        char c=getch();
        if(c=='r' || c=='R')
        {
         GameMenu(PersonValue);
        }
       
}

//make rooms//////////
 void make_first_room()
 {
    Rooms[0].current_floor[0].height =13;
    Rooms[0].current_floor[0].width=2+10;
    Rooms[0].current_floor[0].start_x=rand()%3+2;
    Rooms[0].current_floor[0].start_y=rand()%3+4;
    
    for (int i = 1; i < Rooms[0].current_floor[0].height; i++)
    {
      map[Rooms[0].current_floor[0].start_y+i][Rooms[0].current_floor[0].start_x]='|';
    }
    for (int i = 1; i < Rooms[0].current_floor[0].height; i++)
    {
     
      map[Rooms[0].current_floor[0].start_y+i][Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width]='|';

    }
    for (int i = 1; i < Rooms[0].current_floor[0].width; i++)
    {
      
      map[Rooms[0].current_floor[0].start_y][Rooms[0].current_floor[0].start_x+i]='_';

    }
    for (int i = 1; i < Rooms[0].current_floor[0].width; i++)
    {

      map[Rooms[0].current_floor[0].start_y+Rooms[0].current_floor[0].height-1][Rooms[0].current_floor[0].start_x+i]='_';

    }
    for (int i =Rooms[0].current_floor[0].start_y+1; i <  Rooms[0].current_floor[0].start_y+ Rooms[0].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[0].current_floor[0].start_x; j <Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width; j++)
      {

         map[i][j]='.';

      }
    }

    

    map[9][7]='O';
    //food
    map[10][7]='f';
    map[9][10]='f';
    //traps
    map[14][7]='T';
    map[13][9]='T';
    map[Rooms[0].current_floor[0].start_y+2][Rooms[0].current_floor[0].start_x+5]='T';
    //Gold
    map[13][11]='G';
    map[7][7]='G';
    map[9][8]='S';
    map[10][12]='a';
    //

    map[Rooms[0].current_floor[0].start_y+3][Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width]='+';
 }
 void make_second_room()
 {
    Rooms[1].current_floor[0].height =11;
    Rooms[1].current_floor[0].width=rand()%20+11;
    Rooms[1].current_floor[0].start_x=rand()%3+64;
    Rooms[1].current_floor[0].start_y=rand()%3+6;
    
    for (int i = 1; i < Rooms[1].current_floor[0].height; i++)
    {

      map[Rooms[1].current_floor[0].start_y+i][Rooms[1].current_floor[0].start_x]='|';

    }
    for (int i = 1; i < Rooms[1].current_floor[0].height; i++)
    {


      map[Rooms[1].current_floor[0].start_y+i][Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width]='|';

    }
    for (int i = 1; i < Rooms[1].current_floor[0].width; i++)
    {

      map[Rooms[1].current_floor[0].start_y][Rooms[1].current_floor[0].start_x+i]='_';

    }
    for (int i = 1; i < Rooms[1].current_floor[0].width; i++)
    {

      map[Rooms[1].current_floor[0].start_y+Rooms[1].current_floor[0].height-1][Rooms[1].current_floor[0].start_x+i]='_';

    }
    for (int i =Rooms[1].current_floor[0].start_y+1; i <  Rooms[1].current_floor[0].start_y+ Rooms[1].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[1].current_floor[0].start_x; j <Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width; j++)
      {

         map[i][j]='.';

      }
    }

    map[11][73]='O';
    map[11][75]='b';
    //Traps
    map[11][74]='T';
    map[13][72]='T';
    //foods
    map[14][71]='f';
    map[11][77]='f';
    map[14][77]='f';
    //Golds
    map[10][69]='G';
    
    map[Rooms[1].current_floor[0].start_y+3][Rooms[1].current_floor[0].start_x]='+';


    map[Rooms[1].current_floor[0].start_y+2][Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width]='+';
 }
 void make_third_room()
 {
    Rooms[2].current_floor[0].height =5+7;
    Rooms[2].current_floor[0].width=rand()%20+14;
    Rooms[2].current_floor[0].start_x=150;
    Rooms[2].current_floor[0].start_y=Rooms[1].current_floor[0].start_y;
     
    for (int i = 1; i < Rooms[2].current_floor[0].height; i++)
    {

      map[Rooms[2].current_floor[0].start_y+i][Rooms[2].current_floor[0].start_x]='|';

    }
    for (int i = 1; i < Rooms[2].current_floor[0].height; i++)
    {

      map[Rooms[2].current_floor[0].start_y+i][Rooms[2].current_floor[0].start_x+Rooms[2].current_floor[0].width]='|';

    }
    for (int i = 1; i < Rooms[2].current_floor[0].width; i++)
    {

      map[Rooms[2].current_floor[0].start_y][Rooms[2].current_floor[0].start_x+i]='_';

    }
    for (int i = 1; i < Rooms[2].current_floor[0].width; i++)
    {

      map[Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height-1][Rooms[2].current_floor[0].start_x+i]='_';

    }
    for (int i =Rooms[2].current_floor[0].start_y+1; i <  Rooms[2].current_floor[0].start_y+ Rooms[2].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[2].current_floor[0].start_x; j <Rooms[2].current_floor[0].start_x+Rooms[2].current_floor[0].width; j++)
      {
         map[i][j]='.';
      }
    }

    map[12][155]='O';
    map[10][159]='c';
    map[14][162]='b';
    //trap
    map[10][158]='T';
    map[14][155]='T';
    //Gold
    map[15][157]='G';
    //food
    map[10][157]='f';
    map[14][160]='f';
    map[12][159]='f';


    map[Rooms[2].current_floor[0].start_y+2][Rooms[2].current_floor[0].start_x]='+';
 
    map[Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height-1][Rooms[2].current_floor[0].start_x+5]='+';
 }
 void make_forth_room()
 {
   Rooms[3].current_floor[0].height =rand()%12+9;
    Rooms[3].current_floor[0].width=rand()%20+7;
    Rooms[3].current_floor[0].start_x=rand()%3+2;
    Rooms[3].current_floor[0].start_y=rand()%3+25;
    for (int i = 1; i < Rooms[3].current_floor[0].height; i++)
    {

      map[Rooms[3].current_floor[0].start_y+i][Rooms[3].current_floor[0].start_x]='|';

    }
    for (int i = 1; i < Rooms[3].current_floor[0].height; i++)
    {

      map[Rooms[3].current_floor[0].start_y+i][Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width]='|';

    }
    for (int i = 1; i < Rooms[3].current_floor[0].width; i++)
    {

      map[Rooms[3].current_floor[0].start_y][Rooms[3].current_floor[0].start_x+i]='_';

    }
    for (int i = 1; i < Rooms[3].current_floor[0].width; i++)
    {


      map[Rooms[3].current_floor[0].start_y+Rooms[3].current_floor[0].height-1][Rooms[3].current_floor[0].start_x+i]='_';

    }
    for (int i =Rooms[3].current_floor[0].start_y+1; i <  Rooms[3].current_floor[0].start_y+ Rooms[3].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[3].current_floor[0].start_x; j <Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width; j++)
      {

         map[i][j]='.';

      }
    }
   //make a sotoon
    map[33][6]='O';
    map[34][12]='f';
    map[30][10]='G';
    map[32][6]='f';
    map[30][12]='S';

   //make a stair
    map[30][6]='<';
    map[Rooms[3].current_floor[0].start_y+5][Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width]='+';
 }
 void make_fifth_room()
 {
   Rooms[4].current_floor[0].height =rand()%10+11;
    Rooms[4].current_floor[0].width=rand()%19+11;
    Rooms[4].current_floor[0].start_x=rand()%3+66;
    Rooms[4].current_floor[0].start_y=rand()%3+26;
   
    for (int i = 1; i < Rooms[4].current_floor[0].height; i++)
    {

      map[Rooms[4].current_floor[0].start_y+i][Rooms[4].current_floor[0].start_x]='|';

    }
    for (int i = 1; i < Rooms[4].current_floor[0].height; i++)
    {

      map[Rooms[4].current_floor[0].start_y+i][Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width]='|';

    }
    for (int i = 1; i < Rooms[4].current_floor[0].width; i++)
    {
     
      map[Rooms[4].current_floor[0].start_y][Rooms[4].current_floor[0].start_x+i]='_';

    }
    for (int i = 1; i < Rooms[4].current_floor[0].width; i++)
    {

      map[Rooms[4].current_floor[0].start_y+Rooms[4].current_floor[0].height-1][Rooms[4].current_floor[0].start_x+i]='_';
    }
    for (int i =Rooms[4].current_floor[0].start_y+1; i <  Rooms[4].current_floor[0].start_y+ Rooms[4].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[4].current_floor[0].start_x; j <Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width; j++)
      {

         map[i][j]='.';

      }
    }

    map[33][71]='O';
    map[33][74]='f';
    map[36][71]='f';
    map[30][73]='G';
    map[28][70]='T';
    map[30][78]='S';
    map[33][78]='S';


    map[Rooms[4].current_floor[0].start_y+2][Rooms[4].current_floor[0].start_x]='+';

    map[Rooms[4].current_floor[0].start_y+5][Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width]='+';
 }
 void make_sixth_room()
 {
    Rooms[5].current_floor[0].height =rand()%12+8;
    Rooms[5].current_floor[0].width=6+7;
    Rooms[5].current_floor[0].start_x=rand()%3+130;
    Rooms[5].current_floor[0].start_y=rand()%3+26;

    for (int i = 1; i < Rooms[5].current_floor[0].height; i++)
    {


      map[Rooms[5].current_floor[0].start_y+i][Rooms[5].current_floor[0].start_x]='|';

    }
    for (int i = 1; i < Rooms[5].current_floor[0].height; i++)
    {

      map[Rooms[5].current_floor[0].start_y+i][Rooms[5].current_floor[0].start_x+Rooms[5].current_floor[0].width]='|';

    }
    for (int i = 1; i < Rooms[5].current_floor[0].width; i++)
    {


      map[Rooms[5].current_floor[0].start_y][Rooms[5].current_floor[0].start_x+i]='_';

    }
    for (int i = 1; i < Rooms[5].current_floor[0].width; i++)
    {

      map[Rooms[5].current_floor[0].start_y+Rooms[5].current_floor[0].height-1][Rooms[5].current_floor[0].start_x+i]='_';

    }
    for (int i =Rooms[5].current_floor[0].start_y+1; i <  Rooms[5].current_floor[0].start_y+ Rooms[5].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[5].current_floor[0].start_x; j <Rooms[5].current_floor[0].start_x+Rooms[5].current_floor[0].width; j++)
      {

         map[i][j]='.';

      }
    }
    //make a sotoon
    map[33][136]='O';
    map[33][139]='f';
    map[31][139]='f';
    map[29][140]='G';
    map[Rooms[5].current_floor[0].start_y+2][Rooms[5].current_floor[0].start_x]='+';

    map[Rooms[5].current_floor[0].start_y][Rooms[5].current_floor[0].start_x+3]='+';
 }

//foods on map


//show Rooms//////////

void show_first_room(char doorchoises[3])
{
     init_pair(20,COLOR_BLUE,COLOR_BLACK);
     attron(COLOR_PAIR(20));
     
   for (int i = 1; i < Rooms[0].current_floor[0].height; i++)
    {
      
      mvprintw(Rooms[0].current_floor[0].start_y+i,Rooms[0].current_floor[0].start_x,"|");

    }
    for (int i = 1; i < Rooms[0].current_floor[0].height; i++)
    {

      mvprintw(Rooms[0].current_floor[0].start_y+i,Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width,"|");

    }
    for (int i = 1; i < Rooms[0].current_floor[0].width; i++)
    {

      mvprintw(Rooms[0].current_floor[0].start_y,Rooms[0].current_floor[0].start_x+i,"_");
      
    }
    for (int i = 1; i < Rooms[0].current_floor[0].width; i++)
    {

      mvprintw(Rooms[0].current_floor[0].start_y+Rooms[0].current_floor[0].height-1,Rooms[0].current_floor[0].start_x+i,"_");

    }

    attroff(COLOR_PAIR(20));

    for (int i =Rooms[0].current_floor[0].start_y+1; i <  Rooms[0].current_floor[0].start_y+ Rooms[0].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[0].current_floor[0].start_x; j <Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width; j++)
      {
         mvprintw(i,j,".");
      }
    }

    mvprintw(9,7,"O");
     //food
    mvprintw(10,7,"f");
    mvprintw(9,10,"f");
    //Gold
    mvprintw(13,11,"G");
    mvprintw(7,7,"G");

    mvprintw(9,8,"S");
    mvprintw(10,12,"a");


   mvprintw(Rooms[0].current_floor[0].start_y+3,Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width,"%c",doorchoises[0]);

    Rooms[0].current_floor[0].show=1;
}
void show_second_room(char doorchoises[3])
{
    attron(COLOR_PAIR(20));

    for (int i = 1; i < Rooms[1].current_floor[0].height; i++)
    {

      mvprintw(Rooms[1].current_floor[0].start_y+i,Rooms[1].current_floor[0].start_x,"|");

    }
    for (int i = 1; i < Rooms[1].current_floor[0].height; i++)
    {

      mvprintw(Rooms[1].current_floor[0].start_y+i,Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width,"|");


    }
    for (int i = 1; i < Rooms[1].current_floor[0].width; i++)
    {

      mvprintw(Rooms[1].current_floor[0].start_y,Rooms[1].current_floor[0].start_x+i,"_");

    }
    for (int i = 1; i < Rooms[1].current_floor[0].width; i++)
    {

      mvprintw(Rooms[1].current_floor[0].start_y+Rooms[1].current_floor[0].height-1,Rooms[1].current_floor[0].start_x+i,"_");


    }

    attroff(COLOR_PAIR(20));

    for (int i =Rooms[1].current_floor[0].start_y+1; i <  Rooms[1].current_floor[0].start_y+ Rooms[1].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[1].current_floor[0].start_x; j <Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width; j++)
      {
         
         mvprintw(i,j,".");

      }
    }
    mvprintw(11,73,"O");
    mvprintw(11,75,"b");

    //foods
    mvprintw(14,71,"f");
    mvprintw(11,77,"f");
    mvprintw(14,77,"f");
     //Golds
    mvprintw(10,69,"G");
    
    mvprintw(Rooms[1].current_floor[0].start_y+3,Rooms[1].current_floor[0].start_x,"%c",doorchoises[0]);

    mvprintw(Rooms[1].current_floor[0].start_y+2,Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width,"%c",doorchoises[0]);

}
void show_third_room(char doorchoises[3])
{
  attron(COLOR_PAIR(20));

  for (int i = 1; i < Rooms[2].current_floor[0].height; i++)
    {

      mvprintw(Rooms[2].current_floor[0].start_y+i,Rooms[2].current_floor[0].start_x,"|");

    }
    for (int i = 1; i < Rooms[2].current_floor[0].height; i++)
    {

      mvprintw(Rooms[2].current_floor[0].start_y+i,Rooms[2].current_floor[0].start_x+Rooms[2].current_floor[0].width,"|");

    }
    for (int i = 1; i < Rooms[2].current_floor[0].width; i++)
    {

      mvprintw(Rooms[2].current_floor[0].start_y,Rooms[2].current_floor[0].start_x+i,"_");

    }
    for (int i = 1; i < Rooms[2].current_floor[0].width; i++)
    {

      mvprintw(Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height-1,Rooms[2].current_floor[0].start_x+i,"_");

    }

    attroff(COLOR_PAIR(20));

    for (int i =Rooms[2].current_floor[0].start_y+1; i <  Rooms[2].current_floor[0].start_y+ Rooms[2].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[2].current_floor[0].start_x; j <Rooms[2].current_floor[0].start_x+Rooms[2].current_floor[0].width; j++)
      {
         mvprintw(i,j,".");
      }
    }
    mvprintw(12,155,"O");
    //gold
    mvprintw(15,157,"G");
    //food
    mvprintw(10,157,"f");
    mvprintw(14,160,"f");
    mvprintw(12,159,"f");
    map[10][159]='c';
    map[14][162]='b';
    mvprintw(10,159,"c");
    mvprintw(14,162,"b");

    mvprintw(Rooms[2].current_floor[0].start_y+2,Rooms[2].current_floor[0].start_x,"%c",doorchoises[0]);

    mvprintw(Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height-1,Rooms[2].current_floor[0].start_x+5,"%c",doorchoises[0]);

}
void show_forth_room(char doorchoises[3])
{
   attron(COLOR_PAIR(20));

   for (int i = 1; i < Rooms[5].current_floor[0].height; i++)
    {

      mvprintw(Rooms[5].current_floor[0].start_y+i,Rooms[5].current_floor[0].start_x,"|");


    }
    for (int i = 1; i < Rooms[5].current_floor[0].height; i++)
    {

      mvprintw(Rooms[5].current_floor[0].start_y+i,Rooms[5].current_floor[0].start_x+Rooms[5].current_floor[0].width,"|");

    }
    for (int i = 1; i < Rooms[5].current_floor[0].width; i++)
    {

      mvprintw(Rooms[5].current_floor[0].start_y,Rooms[5].current_floor[0].start_x+i,"_");

    }
    for (int i = 1; i < Rooms[5].current_floor[0].width; i++)
    {


      mvprintw(Rooms[5].current_floor[0].start_y+Rooms[5].current_floor[0].height-1,Rooms[5].current_floor[0].start_x+i,"_");


    }

    attroff(COLOR_PAIR(20));

    for (int i =Rooms[5].current_floor[0].start_y+1; i <  Rooms[5].current_floor[0].start_y+ Rooms[5].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[5].current_floor[0].start_x; j <Rooms[5].current_floor[0].start_x+Rooms[5].current_floor[0].width; j++)
      {
         mvprintw(i,j,".");
      }
    }
    mvprintw(33,136,"O");
   
    mvprintw(33,139,"f");
    mvprintw(31,139,"f");
    mvprintw(29,140,"G");
   

    mvprintw(Rooms[5].current_floor[0].start_y+2,Rooms[5].current_floor[0].start_x,"%c",doorchoises[0]);

    mvprintw(Rooms[5].current_floor[0].start_y,Rooms[5].current_floor[0].start_x+3,"%c",doorchoises[0]);
}
void show_fifth_room(char doorchoises[3])
{

   attron(COLOR_PAIR(20));
  
    for (int i = 1; i < Rooms[4].current_floor[0].height; i++)
    {

      mvprintw(Rooms[4].current_floor[0].start_y+i,Rooms[4].current_floor[0].start_x,"|");

    }
    for (int i = 1; i < Rooms[4].current_floor[0].height; i++)
    {

      mvprintw(Rooms[4].current_floor[0].start_y+i,Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width,"|");


    }
    for (int i = 1; i < Rooms[4].current_floor[0].width; i++)
    {

      mvprintw(Rooms[4].current_floor[0].start_y,Rooms[4].current_floor[0].start_x+i,"_");

    }
    for (int i = 1; i < Rooms[4].current_floor[0].width; i++)
    {


      mvprintw(Rooms[4].current_floor[0].start_y+Rooms[4].current_floor[0].height-1,Rooms[4].current_floor[0].start_x+i,"_");

    }

    attroff(COLOR_PAIR(20));

    for (int i =Rooms[4].current_floor[0].start_y+1; i <  Rooms[4].current_floor[0].start_y+ Rooms[4].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[4].current_floor[0].start_x; j <Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width; j++)
      {
         mvprintw(i,j,".");

      }
    }
    mvprintw(33,71,"O");

    

    mvprintw(33,74,"f");
    mvprintw(36,71,"f");
    mvprintw(30,73,"G");
    mvprintw(30,78,"S");
    mvprintw(33,78,"d");
    

    mvprintw(Rooms[4].current_floor[0].start_y+2,Rooms[4].current_floor[0].start_x,"%c",doorchoises[0]);

   
    mvprintw(Rooms[4].current_floor[0].start_y+5,Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width,"%c",doorchoises[0]);

}
void show_sixth_room(char doorchoises[3])
{
   attron(COLOR_PAIR(20));

   for (int i = 1; i < Rooms[3].current_floor[0].height; i++)
    {

      mvprintw(Rooms[3].current_floor[0].start_y+i,Rooms[3].current_floor[0].start_x,"|");

    }
    for (int i = 1; i < Rooms[3].current_floor[0].height; i++)
    {

      mvprintw(Rooms[3].current_floor[0].start_y+i,Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width,"|");

    }
    for (int i = 1; i < Rooms[3].current_floor[0].width; i++)
    {

      mvprintw(Rooms[3].current_floor[0].start_y,Rooms[3].current_floor[0].start_x+i,"_");


    }
    for (int i = 1; i < Rooms[3].current_floor[0].width; i++)
    {

      mvprintw(Rooms[3].current_floor[0].start_y+Rooms[3].current_floor[0].height-1,Rooms[3].current_floor[0].start_x+i,"_");


    }

    attroff(COLOR_PAIR(20));


    for (int i =Rooms[3].current_floor[0].start_y+1; i <  Rooms[3].current_floor[0].start_y+ Rooms[3].current_floor[0].height-1 ; i++)
    {
      for (int j = 1+ Rooms[3].current_floor[0].start_x; j <Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width; j++)
      {

         mvprintw(i,j,".");

      }
    }
    //sotoon
    mvprintw(33,6,"O");

    

    mvprintw(34,12,"f");
    mvprintw(30,10,"G");
    mvprintw(30,12,"S");
    mvprintw(32,6,"f");
    //stair
    mvprintw(30,6,"<");

    mvprintw(Rooms[3].current_floor[0].start_y+5,Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width,"%c",doorchoises[0]);
}

void show_foods_first_room()
{

   
}
/*
void show_second_room()
{
   
}
void show_foods_first_room()
{
   
}
void show_foods_first_room()
{
   
}
void show_foods_first_room()
{
   
}*/
//corodors////////////
void corridor_1_2()
{
   for (int i = 1; i < 5; i++)
     {

      map[3+Rooms[0].current_floor[0].start_y][Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width+i]='#';

     }
     for (int i = 0; i <(Rooms[1].current_floor[0].start_y+3)-(Rooms[0].current_floor[0].start_y+3) ; i++)
     {


      map[3+Rooms[0].current_floor[0].start_y+i+1][Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width+4]='#';

     }
     for (int i = 0; i <(Rooms[1].current_floor[0].start_x)-(Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width)-5 ; i++)
     {

      map[Rooms[1].current_floor[0].start_y+3][Rooms[0].current_floor[0].start_x+Rooms[0].current_floor[0].width+5+i]='#';

     }
}
void corridor_2_3()
{
  for (int i = 1; i < 6; i++)
     {

      map[Rooms[1].current_floor[0].start_y+2][Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width+i]='#';

     }
     for (int i = 0; i <(Rooms[2].current_floor[0].start_x)-(Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width)-5 ; i++)
     {

      map[Rooms[2].current_floor[0].start_y+2][Rooms[1].current_floor[0].start_x+Rooms[1].current_floor[0].width+5+i]='#';

     }
    
}
void corridor_3_4()
{
   for (int i = 0; i <2 ; i++)
    {

      map[Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height+i][Rooms[2].current_floor[0].start_x+5]='#';

    }
    for (int i = 0; i <(Rooms[2].current_floor[0].start_x+5) -(Rooms[5].current_floor[0].start_x+3); i++)
    {

      map[Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height+2][Rooms[2].current_floor[0].start_x+5 -i]='#';

    }
    for (int i = 0; i <(Rooms[5].current_floor[0].start_y)-(Rooms[2].current_floor[0].height+Rooms[2].current_floor[0].start_y)-2 ; i++)
    {

      map[Rooms[2].current_floor[0].start_y+Rooms[2].current_floor[0].height+2 +i][Rooms[5].current_floor[0].start_x+3]='#';

    }
}
void corridor_4_5()
{
   for (int i = 0; i < 10 ; i++)
    {

      map[Rooms[5].current_floor[0].start_y+2][Rooms[5].current_floor[0].start_x-1-i]='#';

    }
    for (int i = 0; i <(Rooms[4].current_floor[0].start_y+5)-(Rooms[5].current_floor[0].start_y+2) ; i++)
    {

      map[Rooms[5].current_floor[0].start_y+2+i][Rooms[5].current_floor[0].start_x-10]='#';

    }
    for (int i = 0; i <(Rooms[5].current_floor[0].start_x-10)-(Rooms[4].current_floor[0].start_x+Rooms[4].current_floor[0].width); i++)
    {
      
      map[Rooms[4].current_floor[0].start_y+5][Rooms[5].current_floor[0].start_x-10-i]='#';

    }
    
}
void corridor_5_6()
{
   for (int i = 0; i < 5; i++)
    {

      map[Rooms[4].current_floor[0].start_y+2][Rooms[4].current_floor[0].start_x-1-i]='#';
     
    }
    for (int i = 0; i <(Rooms[3].current_floor[0].start_y+5)-(Rooms[4].current_floor[0].start_y+2) ; i++)
    {

      map[Rooms[4].current_floor[0].start_y+2+i][Rooms[4].current_floor[0].start_x-6]='#';

    }
    for (int i = 0; i <(Rooms[4].current_floor[0].start_x-5)-(Rooms[3].current_floor[0].start_x+Rooms[3].current_floor[0].width)-1; i++)
    {

      map[Rooms[3].current_floor[0].start_y+5][Rooms[4].current_floor[0].start_x-6-i]='#';
    }
    
}

//////////////////////////////////
void drawHealthBar()
 {
    int healthBars = (PlayerHealth * 10) / 100;
    mvprintw(2, 170, "Health: ");
    for (int i = 0; i < healthBars; i++) {
        printw("|");
    }
    for (int i = healthBars; i < 10; i++) {
        printw(" ");
    }
    if(PlayerHealth<=0)
    {
      Gameover();
    }

    int eatBars = (hungry * 10) / 100;
    mvprintw(3, 170, "FullEnergy: ");
    for (int i = 0; i < eatBars; i++) {
        printw("|");
    }
    for (int i = eatBars; i < 10; i++) {
        printw(" ");
    }
    
    
}
void Informations_menu()
{

      if(log_or_regi==1)
      {
         
         mvprintw(2,93,"Player : %s",Name_of_User);
         
      }
      else if(log_or_regi==2)
      {
         
         mvprintw(2,97,"%s",Name_of_login_user);
      }
        //score
        mvprintw(2,15,"Score = %d",Score);
        //golds
        init_pair(70,COLOR_YELLOW,COLOR_BLACK);
        attron(COLOR_PAIR(70));
        mvprintw(2,50,"Golds = %d",Gold);
        attroff(COLOR_PAIR(70));

        mvprintw(52,10,"You have %d foods. Press 'e' to eat",foods);

}
//food
void Winmenu()
{
      initscr();
       clear();
       refresh();
       DarHashie();
       clear();
       keypad(stdscr,TRUE);
       Gameplayed=Gameplayed+1;
       int Bazianjamshodeh;
           
        mvprintw(47,88,"Press 'r' to back to main menu") ;  
        
          int num;
        for (int i = 0; i < 1000; i++)
        {
         if(strcmp(users[i].username,Name_of_login_user)==0)
         {
           num=i;
         }
        }
        mvprintw(37,90,"%s   You Win!",users[num].username);
        //golds
        int nowgolds=users[num].golds+Gold;
        mvprintw(40,93,"Golds: %d",nowgolds);
        //scores
        int nowscores=users[num].score+Score;
        mvprintw(42,93,"Scores: %d",nowscores);
        //gameplayed
        int nowgameplayed=users[num].gameplayed+Gameplayed;
        mvprintw(44,93,"GamePlayed: %d",nowgameplayed);
        
        char c=getch();
        if(c=='r' || c=='R')
        {
         GameMenu(PersonValue);
        }
}
void NewGame(int PersonValue)
{
    cbreak();
    noecho();
    clear();
    srand(time(NULL));
    keypad(stdscr,TRUE);
    char doorchoises[3]={'+','@'};
    for (int i = 0; i < 55; i++)
    {
      for (int j = 0; j < 205; j++)
      {
         map[i][j]=' ';
      }
    }
    //first room
    make_first_room();
    //Second room 
    make_second_room();
    //third room
    make_third_room();
    //forth room
    make_forth_room();
    //fifth room
    make_fifth_room();
    //sixth room
    make_sixth_room();

    //random coridoors

    //between 1 & 2
    corridor_1_2();
    //between 2 & 3
    corridor_2_3();
    //between 3 & 4
    corridor_3_4();
    //between 4 & 5
    corridor_4_5();
    //between 5 & 6
    corridor_5_6();
    //
    //
    refresh();
    // Player movement
    show_first_room(doorchoises);
    char symbolplayer = 'B';
    int y = Rooms[0].current_floor[0].start_y + 2;
    int x = Rooms[0].current_floor[0].start_x + 2;
    mvaddch(y, x, symbolplayer);
    map[y][x]='B';
    move(y, x);
    int doortimes=0;
    while (1) {
      Informations_menu();
      drawHealthBar();
        int ch = getch();
        if(ch=='e' || ch=='E')
        {
         if(foods>0)
         {
            foods--;
            hungry+=10;
           foodhealth++;
           if(foodhealth==2)
           {
            PlayerHealth+=10;
           }
           if(foodhealth==4)
           {
            PlayerHealth+=10;
           }
           if(foodhealth==6)
           {
             PlayerHealth+=10;
           }
            if(foodhealth==8)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==10)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==12)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==12)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==12)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==14)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==16)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==18)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==20)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==22)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==24)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==24)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==26)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==28)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==30)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==32)
           {
             PlayerHealth+=10;
           }
           if(foodhealth==34)
           {
             PlayerHealth+=10;
           }


         }
         

        }
        //Back To Settings
        if(ch==81 || ch==113)
        {
         clear();
         refresh();
         endwin();
         GameMenu(PersonValue);
        }
        //Saving Game
        if(ch==83 || ch==115)
        {
            Mapptr=fopen("Map.txt","w");
             for (int i = 1; i < 55; i++)
             {
                 for (int j = 1; j < 204; j++)
                 {
                 fprintf(Mapptr,"%c",map[i][j]);
                 }
                 fprintf(Mapptr,"\n");
             }
             fclose(Mapptr);
        }
        if(ch==109 || ch==77)
        {
            show_first_room(doorchoises);
            show_second_room(doorchoises);
            show_third_room(doorchoises);
            show_forth_room(doorchoises);
            show_fifth_room(doorchoises);
            show_sixth_room(doorchoises);
            //corridors
            //between 1 & 2
            corridor_1_2();
            //between 2 & 3
            corridor_2_3();
            //between 3 & 4
            corridor_3_4();
            //between 4 & 5
            corridor_4_5();
            //between 5 & 6
            corridor_5_6();
        }
        if(ch==78 || ch==110)
        {
           if(doortimes<=1)
           {
             clear();
             show_first_room(doorchoises);
           }
           if(doortimes>=2 && doortimes<=3)
           {
            clear();
            show_first_room(doorchoises);
            show_second_room(doorchoises);
           }
           if(doortimes>=4 && doortimes<=5)
           {
            clear();
            show_first_room(doorchoises);
            show_second_room(doorchoises);
            show_third_room(doorchoises);
           }
           if(doortimes>=6 && doortimes<=7)
           {
              clear();
              show_first_room(doorchoises);
              show_second_room(doorchoises);
              show_third_room(doorchoises);
              show_forth_room(doorchoises);
           }
           if(doortimes>=7 && doortimes<=8)
           {
              clear();
              show_first_room(doorchoises);
              show_second_room(doorchoises);
              show_third_room(doorchoises);
              show_forth_room(doorchoises);
              show_fifth_room(doorchoises);
              show_sixth_room(doorchoises);
           }
           if(doortimes>=8 && doortimes<=9)
           {
              clear();
              show_first_room(doorchoises);
              show_second_room(doorchoises);
              show_third_room(doorchoises);
              show_forth_room(doorchoises);
              show_fifth_room(doorchoises);
              show_sixth_room(doorchoises);
           }
        }
        map[y][x]='.';
        mvaddch(y,x,'.');
         
        switch (ch)
         {
           case '8': 
            if (map[y-1][x] == '.' || map[y-1][x] == '#' || map[y-1][x] == '+' || map[y-1][x] == '<' || map[y-1][x] == '*' ||  map[y-1][x] == 'f' || map[y-1][x] == 'T' || map[y-1][x] == 'G')
            y--;
            stephealth++;
            break;
            case '2': 
            if (map[y+1][x] == '.' || map[y+1][x] == '#' || map[y+1][x] == '+' || map[y+1][x] == '<' || map[y+1][x] == '*' || map[y+1][x] == 'f' || map[y+1][x] == 'T' || map[y+1][x] == 'G')
               y++;
               stephealth++;
            break;
            case '4': 
            if (map[y][x-1] == '.' || map[y][x-1] == '#' || map[y][x-1] == '+' || map[y][x-1] == '<' || map[y][x-1] == '*' || map[y][x-1] == 'f' || map[y][x-1] == 'T' || map[y][x-1] == 'G' )
            x--;
            stephealth++;
            break;
            case '6': 
            if (map[y][x+1] == '.' || map[y][x+1] == '#' || map[y][x+1] == '+' || map[y][x+1] == '<' || map[y][x+1] == '*' || map[y][x+1] == 'f' || map[y][x+1] == 'T' || map[y][x+1] == 'G')
            x++;
            stephealth++;
            break;
            case '7':
            if (map[y-1][x-1] == '.' || map[y-1][x-1] == '#' || map[y-1][x-1] == '+' || map[y-1][x-1] == '<' || map[y-1][x-1] == '*' || map[y-1][x-1] == 'f' || map[y-1][x-1] == 'T' || map[y-1][x-1] == 'f' || map[y-1][x-1] == 'G' || map[y-1][x-1] == 'f')
             y--, x--;
             stephealth++;
             break;
             case '9': 
             if (map[y-1][x+1] == '.' || map[y-1][x+1] == '#' || map[y-1][x+1] == '+' || map[y-1][x+1] == '<' || map[y-1][x+1] == '*' || map[y-1][x+1] == 'f' || map[y-1][x+1] == 'T' || map[y-1][x+1] == 'G')
             y--, x++;
             stephealth++;
             break;
             case '1': 
             if (map[y+1][x-1] == '.' || map[y+1][x-1] == '#' || map[y+1][x-1] == '+' || map[y+1][x-1] == '<' || map[y+1][x-1] == '*' || map[y+1][x-1] == 'f' || map[y+1][x-1] == 'T' || map[y+1][x-1] == 'G')
              y++, x--;
              stephealth++;
              break;
              case '3': 
             if (map[y+1][x+1] == '.' || map[y+1][x+1] == '#' || map[y+1][x+1] == '+' || map[y+1][x+1] == '<' || map[y+1][x+1] == '*'  || map[y+1][x+1] == 'f' || map[y+1][x+1] == 'T' || map[y+1][x+1] == 'G')
             stephealth++;
             y++, x++;
             break;
             case '5': 
             break;
             }

         //stephealth and health
         for (int i = 1; i < 100; i++)
         {
            if(stephealth==60* i )
            {
               PlayerHealth-=10;
            }
         }
             //food
        if(map[y][x]=='f')
        {
            foods++;
        }
        //Gold
        if(map[y][x]=='G')
        {
           Gold++;
           Score+=4;
           attron(COLOR_PAIR(50));
           mvprintw(53,69,"                                                                            ");
           mvprintw(53,90,"You gained a GOLD!");
           attroff(COLOR_PAIR(50));
        }
        //trap
        if(map[y][x]=='T')
        {
         PlayerHealth-=10;
         refresh();
          attron(COLOR_PAIR(50));
          mvprintw(53,69,"                                                                           ");
          mvprintw(53,70,"You steped on a trap!");
          attroff(COLOR_PAIR(50));
         drawHealthBar();
        }

        if(map[y][x]=='<')
        {
          clear();
          baars++;
          if(baars==5)
          {
            Winmenu();
          }
          NewGame(PersonValue);
        }
        //showing 3 steps of coridor
        if(map[y][x]=='#')
        {
         for (int i = 1; i <=2; i++)
         {
            init_pair(22,COLOR_GREEN,COLOR_BLACK);

            attron(COLOR_PAIR(22));
            
            mvaddch(y,x+i,map[y][x+i]);
            mvaddch(y+i,x,map[y+i][x]);
            mvaddch(y-i,x,map[y-i][x]);
            mvaddch(y,x-i,map[y][x-i]);
            
            attroff(COLOR_PAIR(22));
         }
        }
        //showing rooms
       if(map[y][x]=='+')
        {
         doortimes++;
        }
        if(doortimes==2)
        {
          show_second_room(doorchoises);
        }
        if(doortimes==4)
        {
         show_third_room(doorchoises);
        }
        if(doortimes==6)
        {
         show_forth_room(doorchoises);
        }
        if(doortimes==8)
        {
         show_fifth_room(doorchoises);
        }
        if(doortimes==10)
        {
          show_sixth_room(doorchoises);
        }
        if(strcmp(Playercolor,"Red")==0)
        {
         init_pair(40,COLOR_RED,COLOR_BLACK);
         attron(COLOR_PAIR(40));
         mvaddch(y, x, symbolplayer);
         attroff(COLOR_PAIR(40));
        }
        else if(Playercolor[0]=='B')
        {
         attron(COLOR_PAIR(25));
         mvaddch(y, x, symbolplayer);
         attroff(COLOR_PAIR(25));
        }
        else if(strcmp(Playercolor,"White")==0)
        {
         mvaddch(y, x, symbolplayer);
        }
        else
        {
           mvaddch(y, x, symbolplayer);
        }
        
        map[y][x]='B';
        move(y, x);
        refresh();
       
     }
}
//////SecondFuncton:LoadGame/////////////////
void LoadGame()
{

   Mapptr=fopen("Khar.txt","r");
   for (int i = 0; i < 55; i++)
   {
      for (int j = 0; j < 204; j++)
      {
      fscanf(Mapptr,"%c",map[i][j]);
      }
      fgetc(Mapptr);
   }
   fclose(Mapptr);

}

//////Third Function:ScoreTable//////////////


void swap(User* a, User* b) 
{
    User temp=*b;
    *b=*a;
    *a=temp;
}

void sort_users_by_score(User users[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (users[j].score < users[j + 1].score) {
                swap(&users[j], &users[j + 1]);
            }
        }
    }
}

void Second_page_ranks()
{
    initscr();
    noecho();
    cbreak();
    curs_set(FALSE);
    clear();
    refresh();
    DarHashie();
    mvprintw(17,27,"EIGHTTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[7].username,Name_of_login_user)==0 || strcmp(users[7].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(17,61,"Name : %s",users[7].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(17,61,"Name : %s",users[7].username);
    }
    //
    mvprintw(17,93,"Score : %d",users[7].score);
    mvprintw(17,155,"Game Played : %d",users[7].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(17,124,"Golds : %d",users[7].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(19,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(21,27,"NINTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[8].username,Name_of_login_user)==0 || strcmp(users[8].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(21,61,"Name : %s",users[8].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(21,61,"Name : %s",users[8].username);
    }
    //
    mvprintw(21,93,"Score : %d",users[8].score);
    mvprintw(21,155,"Game Played : %d",users[8].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(21,124,"Golds : %d",users[8].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(23,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(25,27,"TENTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[9].username,Name_of_login_user)==0 || strcmp(users[9].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(25,61,"Name : %s",users[9].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(25,61,"Name : %s",users[9].username);
    }
    //
    mvprintw(25,93,"Score : %d",users[9].score);
    mvprintw(25,155,"Game Played : %d",users[9].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(25,124,"Golds : %d",users[9].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(27,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(29,27,"ELEVENTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[10].username,Name_of_login_user)==0 || strcmp(users[10].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(29,61,"Name : %s",users[10].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(29,61,"Name : %s",users[10].username);
    }
    //
    mvprintw(29,93,"Score : %d",users[10].score);
    mvprintw(29,155,"Game Played : %d",users[10].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(29,124,"Golds : %d",users[10].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(31,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(33,27,"TWELVETH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[11].username,Name_of_login_user)==0 || strcmp(users[11].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(33,61,"Name : %s",users[11].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(33,61,"Name : %s",users[11].username);
    }
    //
    mvprintw(33,93,"Score : %d",users[11].score);
    mvprintw(33,155,"Game Played : %d",users[11].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(33,124,"Golds : %d",users[11].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(35,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(37,27,"THIRTENTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[12].username,Name_of_login_user)==0 || strcmp(users[12].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(37,61,"Name : %s",users[12].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(37,61,"Name : %s",users[12].username);
    }
    //
    mvprintw(37,93,"Score : %d",users[12].score);
    mvprintw(37,155,"Game Played : %d",users[12].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(37,124,"Golds : %d",users[12].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(39,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(41,27,"FOURTEENTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[13].username,Name_of_login_user)==0 || strcmp(users[13].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(41,61,"Name : %s",users[13].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(41,61,"Name : %s",users[13].username);
    }
    //
    mvprintw(41,93,"Score : %d",users[13].score);
    mvprintw(41,155,"Game Played : %d",users[13].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(41,124,"Golds : %d",users[13].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(43,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(48,86,"Press 'r' or '1' to turn back");
    DarHashie();
    char d=getch();
    if(d=='r' || d=='R' || d=='1')
    {
      clear();
      refresh();
      endwin();
      ScoreTable(PersonValue);
    }
}
void ranker()
{
     int user_count = 0;
      fptr = fopen("Project.txt", "r");
    if (fptr == NULL)
     {
        printf("Could not open file\n");
        return;
    }

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), fptr))
     {
        if (strstr(line, "Username : ") != NULL)
         {
            strncpy(users[user_count].username, line + 11, strlen(line) - 11);
            users[user_count].username[strlen(line) - 12] = '\0'; 
        }

        if (strstr(line, "Score=") != NULL)
         {
            users[user_count].score = atoi(line + 6);
        }

        if (strstr(line, "Golds=") != NULL) 
        {
            users[user_count].golds = atoi(line + 6);
        }
        if (strstr(line, "Gameplayed=") != NULL)
         {
            users[user_count].gameplayed = atoi(line + 11);
            user_count++;
        }
    }

    fclose(fptr);
}
void ScoreTable(int PersonValue) 
{
   //extracting datas from file(Username,Score and Golds of each person)
    ranker();
    initscr();
    noecho();
    cbreak();
    curs_set(FALSE);
    clear();
    refresh();
    DarHashie();
    sort_users_by_score(users, 1000);
    init_pair(30,COLOR_YELLOW,COLOR_BLACK);
    init_pair(50,COLOR_GREEN,COLOR_BLACK);
    attron(COLOR_PAIR(30));
    mvprintw(8,90,"  ____________");
    mvprintw(9,90," |            |");
    mvprintw(10,90,"(|            |)");
    mvprintw(11,90," |            |");
    mvprintw(12,90,"  \\          /");
    mvprintw(13,90,"   `--------'");
    mvprintw(14,90,"   _|______|_");
    attroff(COLOR_PAIR(30));
    mvprintw(17,27,"FIRST PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[0].username,Name_of_login_user)==0 || strcmp(users[0].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(17,61,"Name : %s",users[0].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(17,61,"Name : %s",users[0].username);
    }
    //
    mvprintw(17,93,"Score : %d",users[0].score);
    
    mvprintw(17,139,"!!Goat!!");
    
    mvprintw(17,155,"Game Played : %d",users[0].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(17,124,"Golds : %d",users[0].golds);
    mvprintw(10,94,"$WINNER$");
    mvprintw(11,93,"%s",users[0].username);
    mvprintw(9,92,"************");
    mvprintw(12,93,"**********");
    attroff(COLOR_PAIR(30));
    mvprintw(19,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(21,27,"SECOND PLAYER =>");
    if(strcmp(users[1].username,Name_of_login_user)==0 || strcmp(users[1].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(21,61,"Name : %s",users[1].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(21,61,"Name : %s",users[1].username);
    }
    mvprintw(21,93,"Score : %d",users[1].score);
    
    mvprintw(21,138,"!!Victor!!");
    
    mvprintw(21,155,"Game Played : %d",users[1].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(21,124,"Golds : %d",users[1].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(23,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(25,27,"THIRD PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[2].username,Name_of_login_user)==0 || strcmp(users[2].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(25,61,"Name : %s",users[2].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(25,61,"Name : %s",users[2].username);
    }
    //
    mvprintw(25,93,"Score : %d",users[2].score);
    
    mvprintw(25,138,"!!Master!!");
    
    mvprintw(25,155,"Game Played : %d",users[2].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(25,124,"Golds : %d",users[2].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(27,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(29,27,"FORTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[3].username,Name_of_login_user)==0 || strcmp(users[3].username,Name_of_User)==0)
    {
       refresh();
       attron(COLOR_PAIR(50));
       mvprintw(29,61,"Name : %s",users[3].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       refresh();
       mvprintw(29,61,"Name : %s",users[3].username);
    }
    //
    mvprintw(29,93,"Score : %d",users[3].score);
    mvprintw(29,155,"Game Played : %d",users[3].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(29,124,"Golds : %d",users[3].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(31,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(33,27,"FIFTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[4].username,Name_of_login_user)==0 || strcmp(users[4].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(33,61,"Name : %s",users[4].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(33,61,"Name : %s",users[4].username);
    }
    //
    mvprintw(33,93,"Score : %d",users[4].score);
    mvprintw(33,155,"Game Played : %d",users[4].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(33,124,"Golds : %d",users[4].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(35,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(37,27,"SIXTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[5].username,Name_of_login_user)==0 || strcmp(users[5].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(37,61,"Name : %s",users[5].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(37,61,"Name : %s",users[5].username);
    }
    //
    mvprintw(37,93,"Score : %d",users[5].score);
    mvprintw(37,155,"Game Played : %d",users[5].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(37,124,"Golds : %d",users[5].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(39,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(41,27,"SEVENTH PLAYER =>");
    //check is the member between Ranks
    if(strcmp(users[6].username,Name_of_login_user)==0 || strcmp(users[6].username,Name_of_User)==0)
    {
       attron(COLOR_PAIR(50));
       mvprintw(41,61,"Name : %s",users[6].username);
       attroff(COLOR_PAIR(50));
    }
    else
    {
       mvprintw(41,61,"Name : %s",users[6].username);
    }
    //
    mvprintw(41,93,"Score : %d",users[6].score);
    mvprintw(41,155,"Game Played : %d",users[6].gameplayed);
    attron(COLOR_PAIR(30));
    mvprintw(41,124,"Golds : %d",users[6].golds);
    attroff(COLOR_PAIR(30));
    mvprintw(43,25,"--------------------------------------------------------------------------------------------------------------------------------------------------");
    mvprintw(48,86,"Press 'r' to turn back");
    mvprintw(47,82,"Press '2' to see next page of RANKS");
    
    char c=getch();
    if(c== 'r' || c=='R')
    {
      clear();
      GameMenu(PersonValue);
    }
    if(c=='2')
    {
      clear();
      Second_page_ranks();
    }
    refresh();
    getch();
    endwin();
}

/////Forth Function:Settings and functions of this part/////////////////


//Player Color////

void Color(int PersonValue)
{
    initscr();
    clear();
    raw();
    keypad(stdscr, TRUE);
    noecho();
    nodelay(stdscr, FALSE);
    cbreak();
    curs_set(0);
    refresh();
    DarHashie();
    int height = 26, width = 147, start_y = 15, start_x = 26;
    char* choise[3] ={"Red", "Blue", "White"};
    WINDOW* win = newwin(height, width, start_y, start_x);
    mvwhline(win,  7, 1, 0, 145);
    mvwhline(win, 13, 1, 0, 145);
    mvwhline(win, 19, 1, 0, 145);
    box(win,0,0);
    wattron(win, COLOR_PAIR(15));
    mvwprintw(win,21 , 60, "Press 'r' to turn back");
    wattroff(win, COLOR_PAIR(15));
    refresh();
    DarHashie();
    int numchoise = 3;
    int whitch_one = 1;
    int choose = 0;
    int get;
    keypad(win,TRUE);
    while (1)
     {
        int x = 67;
        int y = 5;
        for (int i = 0; i < numchoise; ++i)
        {
            if (whitch_one == i + 1)
            {
                wattron(win, A_REVERSE);
                mvwprintw(win, y, x, "%s", choise[i]);
                wattroff(win, A_REVERSE);
            } else
            {
                mvwprintw(win, y, x, "%s", choise[i]);
            }
            y += 6;
        }
        wrefresh(win);
        get = wgetch(win);
        if(get=='r' || get=='R')
        {
           Settings(PersonValue);
        }
        if (get == KEY_UP)
        {
            if (whitch_one == 1)
            {
                whitch_one = numchoise;
            }
            else
            {
                --whitch_one;
            }
        }
        else if (get == KEY_DOWN)
        {
            if (whitch_one == numchoise)
            {
                whitch_one = 1;
            }
            else
            {
                ++whitch_one;
            }
        }
        else if (get == 10)
        {
            choose = whitch_one;
            break;
        }
     }
    clrtoeol();
    refresh();

    if (strcmp(choise[choose-1], "Red") == 0)
    {
        strcpy(Playercolor,"Red");
        Settings(PersonValue);
    }
    else if (strcmp(choise[choose-1], "Blue") == 0)
    {
        strcpy(Playercolor,"Blue");
        
        Settings(PersonValue);
    }
    else if (strcmp(choise[choose-1], "White") == 0)
    {
        strcpy(Playercolor,"White");
        Settings(PersonValue);
    }

    endwin();
}
//Choose Music////
void ChooseMusic(int PersonValue) {

    initscr();
    clear();
    raw();                  
    keypad(stdscr, TRUE);  
    noecho();
    nodelay(stdscr, FALSE); 
    cbreak();               
    curs_set(0);
    int height = 26, width = 147, start_y = 15, start_x = 26;
    WINDOW* win = newwin(height, width, start_y, start_x);
    box(win,0,0);
    DarHashie();
    refresh();
    int numchoise = 3; 
    int whitch_one = 1;
    int choose = 0;
    int get;
    keypad(win,TRUE);
     while (1) {
        mvwprintw(win, 1, 52, "Here is the GUIDESIDE for playing music");
        mvwprintw(win, 4, 58, "Press 'C' to change the song");
        mvwprintw(win, 7, 59, "Press 'E' to end the song");
        mvwprintw(win, 10, 59, "Press 'S' to start a song");
        mvwprintw(win,13, 52, "Press '+' to increase volume of the song");
        mvwprintw(win,16 , 52, "Press '-' to decrease volume of the song");
        init_pair(15, COLOR_YELLOW, COLOR_BLUE);
        wattron(win, COLOR_PAIR(15));
        mvwprintw(win,21 , 60, "Press 'r' to turn back");
        wattroff(win, COLOR_PAIR(15));
        wrefresh(win);
        get = wgetch(win);
        
        if (get == 'r' || get == 'R') {
            clear();
            endwin(); 
            Settings(PersonValue);
            return;
        } else if (get == 'c' || get=='C') { 
            currentSong = (currentSong + 1) % NUM_SONGS;
            Mix_HaltMusic();
            playMusic(songs[currentSong]);
        } else if (get == '=') { 
            volume = (volume + 10 > MIX_MAX_VOLUME) ? MIX_MAX_VOLUME : volume + 10;
            Mix_VolumeMusic(volume);
        } else if (get == '-') { 
            volume = (volume - 10 < 0) ? 0 : volume - 10;
            Mix_VolumeMusic(volume);
        } else if (get == 'e' || get == 'E')
         { 
            if (isPlaying) {
                Mix_PauseMusic();
                isPlaying = 0;
            } else {
                Mix_ResumeMusic();
                isPlaying = 1;
            }
        } else if (get == 's' || get == 'S') { 
            Mix_HaltMusic();
            Mix_FreeMusic(Mix_LoadMUS(songs[currentSong]));
            playMusic(songs[currentSong]);
        }
    }
    clrtoeol();
    refresh();
    

}
void Settings(int PersonValue)
{
    initscr();
    clear();
    raw();                  
    keypad(stdscr, TRUE);  
    noecho();
    nodelay(stdscr, FALSE); 
    cbreak();               
    curs_set(0);
    DarHashie();
    refresh();
    int height = 26, width = 147, start_y = 15, start_x = 26;
    char* choise[3] ={"Change Level", "Player Color", "Choose Music"};
    WINDOW* win = newwin(height, width, start_y, start_x);
    mvwhline(win,  7, 1, 0, 145);
    mvwhline(win, 13, 1, 0, 145);
    mvwhline(win, 19, 1, 0, 145);
    box(win,0,0);
    DarHashie();
    int numchoise = 3; 
    int whitch_one = 1;
    int choose = 0;
    int get;
    keypad(win,TRUE);
     while (1) 
     {
        int x = 67;
        int y = 5;
        for (int i = 0; i < numchoise; ++i)
        {
            if (whitch_one == i + 1)
            {
                wattron(win, A_REVERSE);
                mvwprintw(win, y, x, "%s", choise[i]);
                wattroff(win, A_REVERSE);
            } else 
            {
                mvwprintw(win, y, x, "%s", choise[i]);
            }
            y += 6;
        }
        init_pair(15,COLOR_YELLOW,COLOR_BLUE);
        wattron(win,COLOR_PAIR(15));
        mvwprintw(win,21,63,"Press 'r' to turn back");
        wattroff(win,COLOR_PAIR(15));
        wrefresh(win);
        get = wgetch(win);
        if (get == KEY_UP)
        {
            if (whitch_one == 1) 
            {
                whitch_one = numchoise;
            }
            else
            {
                --whitch_one;
            }
        }
        else if (get == KEY_DOWN)
        {
            if (whitch_one == numchoise)
            {
                whitch_one = 1;
            }
            else
            {
                ++whitch_one;
            }
        } 
        else if(get==82 || get==114)
        {
         clear();
         GameMenu(PersonValue);

        }
        else if (get == 10) 
        { 
            choose = whitch_one;
            break;
        }

     }
    clrtoeol();
    refresh();
    //Press Change Level
    if(strcmp(choise[choose-1], "Change Level") == 0)
    {
       
    }
    //Press 
    else if(strcmp(choise[choose-1], "Player Color") == 0)
    {
        clear();
        Color(PersonValue);
        refresh();
        getch();
    }
    //Press ScoreTable_3
    else if(strcmp(choise[choose-1], "Choose Music") == 0)
    {
        clear();
        ChooseMusic(PersonValue);
        refresh();
        getch();
    }
}
//Profile and Functions
void FindInformations()
{
 
    fptr = fopen("Project.txt", "r");
    if (fptr == NULL) {
        perror("Error opening file");
        return EXIT_FAILURE;
    }

    
    char line[1000];
   
   
    int found=0;

    while (fgets(line, sizeof(line), fptr))
     {
        if (strstr(line, "Username : ") != NULL) 
        {
            strncpy(nowuser.username, line + 11, strlen(line) - 11);
            nowuser.username[strlen(line) - 12] = '\0';
            if (strcmp(nowuser.username, Name_of_login_user) == 0 || strcmp(nowuser.username, Name_of_User) == 0) {
                found = 1;
            }
        }

        if (found && strstr(line, "Score=") != NULL) {
            nowuser.score = atoi(line + 6);
        }

        if (found && strstr(line, "Golds=") != NULL) {
            nowuser.gold = atoi(line + 6);
        }

        if (found && strstr(line, "Gameplayed=") != NULL) {
            nowuser.gameplayed = atoi(line + 11);
            break; 
        }
    
       }
}
void Profile()
{
       //UserName
       initscr();
       refresh();
       int height = 26, width = 147, start_y = 15, start_x = 26;
       WINDOW* win1 = newwin(26, 147, 15, 26);
       box(win1,0,0);
       refresh();
       DarHashie();  
       if(log_or_regi==1)
       mvprintw(21,90,"Name : %s",Name_of_User);
       else if(log_or_regi==2)
       mvprintw(21,90,"Name : %s",Name_of_login_user);
           
       //
        FindInformations();
        //Golds
         mvprintw(27,90,"Golds : %d",nowuser.gold);
       //score
        mvprintw(24,90,"Score : %d",nowuser.score);
        //Gameplayed
        mvprintw(30,90,"GamePlayed: %d",nowuser.gameplayed);
         
         keypad(stdscr,TRUE);
       mvprintw(40,87,"Press 'r' to return");
       char ch=getch();
       if(ch=='r' || ch=='R')
       {
         GameMenu(PersonValue);
       }


       refresh();
       //Golds
       //mvprintw()
}
////////////////////////////
///////GameMenu/////////////
////////////////////////////
int GameMenu(int PersonValue)
{
    initscr();
    clear();
    raw();                  
    keypad(stdscr, TRUE);  
    noecho();
    nodelay(stdscr, FALSE); 
    cbreak();               
    curs_set(0);
    DarHashie();
    //finding what is the name of the user
    Personnumber=PersonValue-1;
    
    //
    int height = 38, width = 147, start_y = 10, start_x = 26;
    char *choise[6] = {"New Game", "Load Game", "ScoreTable", "Settings","Profile", "Exit"};
    int numchoise = 6; 
    int whitch_one = 1;
    int choose = 0;
    int get;
    WINDOW *win = newwin(height, width, start_y, start_x);  
    keypad(win, TRUE);
    box(win, 0, 0);
    init_pair(10, COLOR_RED, COLOR_BLACK);
    wattron(win, COLOR_PAIR(10));
    wattron(win, A_BOLD);
    mvwprintw(win, 1, 47, "!!!!!!!!!!!!!!!WELCOME TO ROGUE GAME!!!!!!!!!!!!!!!");
    wattroff(win,COLOR_PAIR(10));
    wattron(win,COLOR_PAIR(25));
    mvwprintw(win,2,COLS/2-36,"%s",Name_of_User);
    wattroff(win,COLOR_PAIR(25));
    wattron(win,COLOR_PAIR(10));
    mvwprintw(win,3,61,"I WANT TO KIIILLL YOU");
    wattroff(win,COLOR_PAIR(10));
    mvwhline(win,  7, 1, 0, 145);
    mvwhline(win, 13, 1, 0, 145);
    mvwhline(win, 19, 1, 0, 145);
    mvwhline(win, 25, 1, 0, 145);
    mvwhline(win, 31, 1, 0, 145);
    DarHashie();
    box(win, 0, 0);
    refresh();
    while (1) 
    {
        int x = 67;
        int y = 5;
        for (int i = 0; i < numchoise; ++i)
        {
            if (whitch_one == i + 1)
            {
                wattron(win, A_REVERSE);
                mvwprintw(win, y, x, "%s", choise[i]);
                wattroff(win, A_REVERSE);
            } else 
            {
                mvwprintw(win, y, x, "%s", choise[i]);
            }
            y += 6;
        }
        wrefresh(win);
        get = wgetch(win);
        if (get == KEY_UP)
        {
            if (whitch_one == 1) 
            {
                whitch_one = numchoise;
            }
            else
            {
                --whitch_one;
            }
        }
        else if (get == KEY_DOWN)
        {
            if (whitch_one == numchoise)
            {
                whitch_one = 1;
            }
            else
            {
                ++whitch_one;
            }
        } 
        else if (get == 10) 
        { 
            choose = whitch_one;
            break;
        }
    }
    clrtoeol();
    refresh();

    //Press New game_1
    if(strcmp(choise[choose-1], "New Game") == 0)
    {
        NewGame(PersonValue);
    }
    //Press Load Game_2
    else if(strcmp(choise[choose-1], "Load Game") == 0)
    {

        LoadGame(PersonValue);
    }
    //Press ScoreTable_3
    else if(strcmp(choise[choose-1], "ScoreTable") == 0)
    {
        clear();
        ScoreTable(PersonValue);
        refresh();
        getch();
    }
    //Press Settings_4
    else if(strcmp(choise[choose-1], "Settings") == 0)
    {
        clear();
        refresh();
        endwin();
        Settings(PersonValue);
        refresh();
        getch();
    }
    //Press Profile_5
    else if(strcmp(choise[choose-1],"Profile")==0)
    {
      clear();
      refresh();
      endwin();
      Profile();
    }
    else if(strcmp(choise[choose-1], "Exit") == 0)
    {
        clear();
        DarHashie();
        mvprintw(27,67,"Are you sure? press 'y' if you want to exit or press 'n' if you want to back");
        DarHashie();
        refresh();
        move(28,80);
        char c=getch();
        if(c=='y' || c=='Y')
        {

         clear();

         refresh();

         endwin();

         exit(0);
        }
        else if(c=='n' || c=='N')
        {
         GameMenu(PersonValue);
        }
    }
    wattroff(win, COLOR_PAIR(10));
    wattroff(win, A_BOLD);
    delwin(win); 
    refresh(); 
    getch(); 
    endwin();
}

int main()
{
     initscr();
      start_color();
   /*Play_Music();*/
       //Hashie
       
        DarHashie();
         refresh();
         attroff(COLOR_PAIR(5));
         init_pair(1,COLOR_RED,COLOR_GREEN);
         attron(COLOR_PAIR(1));
         /////////////////////////////////////////////
         mvprintw(15,70,"########################################################\n");
         mvprintw(16,70,"#!!!!!!!!!!!!!!!!!!!!!!!!!*!!!!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(17,70,"#!!!!!!!!!!!!!!!!!!!!!!!!***!!!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(18,70,"#!!!!!!!!!!!!!!!!!!!!!!!*****!!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(19,70,"#!!!!!!!!!!!!!!!!!!!!!!*******!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(20,70,"#!!!!!!!!!!!!!!!!!!!!!*********!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(21,70,"#!!!!!!!!!!!!!!!!!!!!***********!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(22,70,"#!!!!!!!!!!!!!!!!!!!*************!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(23,70,"#!!!!!!!!!!!!!!!!!!***************!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(24,70,"#!!!!!!!!!!!!!!!!!*****************!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(25,70,"#!!!!!!!!!!!!!!!!*******************!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(26,70,"#!!!!!!!!!!!!!!!*********************!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(27,70,"#!!!!!!!!!!!!!!*!Welcome to our Game!*!!!!!!!!!!!!!!!!!#\n");
         mvprintw(28,70,"#!!!!!!!!!!!!!!!********Rogue********!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(29,70,"#!!!!!!!!!!!!!!!!*******************!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(30,70,"#!!!!!!!!!!!!!!!!!*****************!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(31,70,"#!!!!!!!!!!!!!!!!!!***************!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(32,70,"#!!!!!!!!!!!!!!!!!!!*************!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(33,70,"#!!!!!!!!!!!!!!!!!!!!***********!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(34,70,"#!!!!!!!!!!!!!!!!!!!!!*********!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(35,70,"#!!!!!!!!!!!!!!!!!!!!!!*******!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(36,70,"#!!!!!!!!!!!!!!!!!!!!!!!*****!!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(37,70,"#!!!!!!!!!!!!!!!!!!!!!!!!***!!!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(38,70,"#!!!!!!!!!!!!!!!!!!!!!!!!!*!!!!!!!!!!!!!!!!!!!!!!!!!!!!#\n");
         mvprintw(39,70,"########################################################\n");
         mvprintw(40,70,"\n\n\n\n");
         attroff(COLOR_PAIR(1));
         mvprintw(45,70,"Press any keys to Continue!\n");
         init_pair(5,COLOR_WHITE,COLOR_BLACK);
         attron(COLOR_PAIR(5));
         mvprintw(5,20,"##############################################################################################################################################################\n");
         for (int i = 6 ;i < 50; i++)
         {
           mvprintw(i,20,"#");
         }
         for (int j = 6; j <50 ; j++)
         {
            mvprintw(j,177,"#");
         }
         
         mvprintw(51,20,"##############################################################################################################################################################\n");
         move(46,70);
         //////////////////////////////////////////////////////////////////////////////////////////////////////////
         char alaki=getch();
         clear();
          
   char Khorooji;
   while (1)
   {
      init_pair(3,COLOR_BLACK,COLOR_YELLOW);
      attron(COLOR_PAIR(3));
      Khorooji = Login_Register();
      attroff(COLOR_PAIR(3));
      if (Khorooji == 'R' || Khorooji == 'L')
      {

         break;
      }
   }
   if (Khorooji == 'L')
   {
      init_pair(4,COLOR_BLUE,COLOR_YELLOW);
      attron(COLOR_PAIR(4));
      Login();
      attroff(COLOR_PAIR(4));
   }
   if (Khorooji == 'R')
   {
      int VoroodByRegister;
      //COLOR
      init_pair(2,COLOR_BLACK,COLOR_YELLOW);
      attron(COLOR_PAIR(2));
      //
      Register();
      attroff(COLOR_PAIR(2));
   }
   
   char c = getch();

   refresh();
   endwin();
   return 0;
}
